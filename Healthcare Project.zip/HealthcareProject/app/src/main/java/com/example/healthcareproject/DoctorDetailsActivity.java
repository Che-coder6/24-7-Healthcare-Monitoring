package com.example.healthcareproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDetailsActivity extends AppCompatActivity {

    private String[][] doctor_details1 =
            {
                    {"Doctor Name: Ajit Saste", "Hospital Address: Pimpri", "Exp: 5yrs", "Mobile No: 9898989898", "600"},
                    {"Doctor Name: Prasad Pawar", "Hospital Address: Nigdi", "Exp: 15yrs", "Mobile No:7898989898", "900"},
                    {"Doctor Name: Swapnil Kale", "Hospital Address: Pune", "Exp: 8yrs", "Mobile No:8898989898", "300"},
                    {"Doctor Name: Deepak Deshmukh", "Hospital Address: Chinchwad", "Exp: 6yrs", "Mobile No: 9898860000", "500"},
                    {"Doctor Name: Ashok Panda", "Hospital Address: Katraj", "Exp: 7yrs", "Mobile No:7798989898", "806"}
            };
    private String[][] doctor_details2 =
            {
                    {"Doctor Name: Rajesh Singh", "Hospital Address: Varanasi", "Exp: 10yrs", "Mobile No: 9123456789", "700"},
                    {"Doctor Name: Neha Gupta", "Hospital Address: Lucknow", "Exp: 12yrs", "Mobile No: 9234567890", "850"},
                    {"Doctor Name: Amit Sharma", "Hospital Address: Jaipur", "Exp: 9yrs", "Mobile No: 9345678901", "400"},
                    {"Doctor Name: Priya Menon", "Hospital Address: Kochi", "Exp: 11yrs", "Mobile No: 9456789012", "650"},
                    {"Doctor Name: Vikram Patel", "Hospital Address: Ahmedabad", "Exp: 14yrs", "Mobile No: 9567890123", "920"}
            };
    private String[][] doctor_details3 =
            {
                    {"Doctor Name: Sunita Desai", "Hospital Address: Mumbai", "Exp: 20yrs", "Mobile No: 9988776655", "1500"},
                    {"Doctor Name: Rohit Verma", "Hospital Address: Delhi", "Exp: 7yrs", "Mobile No: 9876543210", "750"},
                    {"Doctor Name: Kavita Rao", "Hospital Address: Bengaluru", "Exp: 5yrs", "Mobile No: 9765432109", "680"},
                    {"Doctor Name: Manish Tiwari", "Hospital Address: Hyderabad", "Exp: 13yrs", "Mobile No: 9654321098", "900"},
                    {"Doctor Name: Suresh Nair", "Hospital Address: Chennai", "Exp: 18yrs", "Mobile No: 9543210987", "1200"}
            };
    private String[][] doctor_details4 =
            {
                    {"Doctor Name: Anjali Kapoor", "Hospital Address: Chandigarh", "Exp: 6yrs", "Mobile No: 9432109876", "600"},
                    {"Doctor Name: Abhishek Mehta", "Hospital Address: Surat", "Exp: 11yrs", "Mobile No: 9321098765", "800"},
                    {"Doctor Name: Pooja Iyer", "Hospital Address: Mysuru", "Exp: 8yrs", "Mobile No: 9210987654", "700"},
                    {"Doctor Name: Tarun Joshi", "Hospital Address: Indore", "Exp: 10yrs", "Mobile No: 9109876543", "750"},
                    {"Doctor Name: Veena Reddy", "Hospital Address: Vijayawada", "Exp: 9yrs", "Mobile No: 9098765432", "720"}
            };
    private String[][] doctor_details5 =
            {
                    {"Doctor Name: Harish Gupta", "Hospital Address: Bhopal", "Exp: 15yrs", "Mobile No: 9987654321", "850"},
                    {"Doctor Name: Seema Shah", "Hospital Address: Thane", "Exp: 12yrs", "Mobile No: 9876543211", "950"},
                    {"Doctor Name: Anil Saxena", "Hospital Address: Nashik", "Exp: 13yrs", "Mobile No: 9765432110", "800"},
                    {"Doctor Name: Reena Kaur", "Hospital Address: Amritsar", "Exp: 14yrs", "Mobile No: 9654321109", "900"},
                    {"Doctor Name: Kiran Joshi", "Hospital Address: Nagpur", "Exp: 16yrs", "Mobile No: 9543211098", "880"}
            };

    TextView tv;
    Button btn;
    String[][] doctor_details = {};
    HashMap<String, String> item;
    ArrayList<HashMap<String, String>> list;
    SimpleAdapter sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_details);

        tv = findViewById(R.id.textViewHATitle);
        btn = findViewById(R.id.buttonHADBack);

        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        if (title.compareTo("Family Physicians") == 0)
            doctor_details = doctor_details1;
        else if (title.compareTo("Dietician") == 0)
            doctor_details = doctor_details2;
        else if (title.compareTo("Dentist") == 0)
            doctor_details = doctor_details3;
        else if (title.compareTo("Surgeon") == 0)
            doctor_details = doctor_details4;
        else
            doctor_details = doctor_details5;

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DoctorDetailsActivity.this, FindDoctorActivity.class));
            }
        });

        list = new ArrayList<>();
        for (int i = 0; i < doctor_details.length; i++) {
            item = new HashMap<>();
            item.put("line1", doctor_details[i][0]);
            item.put("line2", doctor_details[i][1]);
            item.put("line3", doctor_details[i][2]);
            item.put("line4", doctor_details[i][3]);
            item.put("line5", "Cons Fees: " + doctor_details[i][4] + "/-");
            list.add(item);
        }
        sa = new SimpleAdapter(this,
                list,
                R.layout.multi_lines,
                new String[]{"line1", "line2", "line3", "line4", "line5"},
                new int[]{R.id.line_a, R.id.line_b, R.id.line_c, R.id.line_d, R.id.line_e});

        ListView lst = findViewById(R.id.listviewHA);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent it = new Intent(DoctorDetailsActivity.this, BookAppointmentActivity.class);
                it.putExtra("text1", title);
                it.putExtra("text2", doctor_details[i][0]);
                it.putExtra("text3", doctor_details[i][1]);
                it.putExtra("text4", doctor_details[i][3]);
                it.putExtra("text5", doctor_details[i][4]);
                startActivity(it);
            }
        });
    }
}